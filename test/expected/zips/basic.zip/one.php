<?php
// one.php